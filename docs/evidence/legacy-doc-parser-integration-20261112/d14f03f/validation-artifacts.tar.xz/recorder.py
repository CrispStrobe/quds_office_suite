#!/usr/bin/env python3
"""Seal exact Quds parser/engine batch evidence without changing source gates."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/143959eed1a1/quds_office_suite')
SCRATCH = ROOT.parent
COMMIT = 'd14f03f198a9735c660d0f8ae18ba6fc316fcf25'
INPUT = ROOT / 'build/parser-integration/d14f03f'
OUTPUT = ROOT / 'docs/evidence/legacy-doc-parser-integration-20261112/d14f03f'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    published = read_json(ROOT / 'build/quds-published-d14f03f-source.json')
    upstream = read_json(OUTPUT / 'upstream-files.json')
    assert upstream['commit'] == COMMIT
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).strip()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == published['publishedCommit']
    artifacts = {}
    summaries = {}
    for component, expected_count in [('engine', 123), ('parser', 66)]:
        folder = INPUT / f'{component}-batches'
        shutil.copyfile(SCRATCH / f'run_quds_{component}_batches.py', folder / 'runner.py')
        plan, report = read_json(folder / 'plan.json'), read_json(folder / 'report.json')
        before, after = read_json(folder / 'source-before.json'), read_json(folder / 'source-after.json')
        assert before == after and not before['status']
        assert before['head'] == published['measuredLocalCommit']
        assert report['success'] and report['sourceUnchanged'] and report['allSuitesExactlyOnce']
        assert report['suiteCount'] == report['executedSuiteCount'] == expected_count
        inventory = plan['suiteInventory']
        paths = [entry['path'] for entry in inventory]
        assert len(paths) == len(set(paths)) == expected_count
        assert paths == [path for batch in report['batches'] for path in batch['suites']]
        package = 'quds_office_engine' if component == 'engine' else 'legacy_doc_parser'
        for entry in inventory:
            assert digest((ROOT / 'packages' / package / entry['path']).read_bytes()) == entry['sha256']
        for batch in report['batches']:
            assert batch['exitCode'] == 0 and batch['events']['doneSuccess']
            assert not batch['remainingScratchFiles']
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                artifacts[f'{component}/{path.relative_to(folder)}'] = path.read_bytes()
        write_json(OUTPUT / f'{component}-report.json', report)
        write_json(OUTPUT / f'{component}-inventory.json', inventory)
        summaries[component] = {
            'suites': expected_count,
            'batches': len(report['batches']),
            'testCounts': report['testCounts'],
            'durationSeconds': report['durationSeconds'],
            'allSuitesExactlyOnce': True,
            'sourceUnchanged': True,
            'noScratchFilesRemain': True,
            'runnerSha256': digest((folder / 'runner.py').read_bytes()),
            'minimumFreeBytesAtBatchBoundary': min(
                batch[key] for batch in report['batches'] for key in ['freeBytesBefore', 'freeBytesAfter']
            ),
        }
    assert read_json(INPUT / 'engine-batches/source-before.json') == read_json(INPUT / 'parser-batches/source-before.json')
    commands = {}
    for name in ['parser-analysis', 'engine-analysis', 'parser-python']:
        record = read_json(INPUT / f'{name}.json')
        assert record['exitCode'] == 0
        commands[name] = record
        for suffix in ['json', 'log']:
            artifacts[f'commands/{name}.{suffix}'] = (INPUT / f'{name}.{suffix}').read_bytes()
    parser_analysis = (INPUT / 'parser-analysis.log').read_text()
    diagnostics = {
        level: len(re.findall(rf'^\s*{level} - ', parser_analysis, re.MULTILINE))
        for level in ['error', 'warning', 'info']
    }
    assert diagnostics == {'error': 0, 'warning': 0, 'info': 325}
    assert 'No issues found!' in (INPUT / 'engine-analysis.log').read_text()
    python_tests = int(re.search(r'Ran (\d+) tests', (INPUT / 'parser-python.log').read_text()).group(1))
    assert python_tests == 162
    artifacts['publication.json'] = json.dumps(published, indent=2).encode() + b'\n'
    artifacts['recorder.py'] = Path(__file__).read_bytes()
    archive_path = OUTPUT / 'validation-artifacts.tar.xz'
    with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
        for name, data in sorted(artifacts.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            archive.addfile(item, io.BytesIO(data))
    manifest = {
        'archive': archive_path.name,
        'sha256': digest(archive_path.read_bytes()),
        'members': {name: {'sha256': digest(data), 'size': len(data)} for name, data in sorted(artifacts.items())},
    }
    with tarfile.open(archive_path, 'r:xz') as archive:
        actual = {member.name: archive.extractfile(member).read() for member in archive.getmembers()}
    assert actual == artifacts
    write_json(OUTPUT / 'validation-artifacts.manifest.json', manifest)
    summary = {
        'schema': 'quds-office/legacy-parser-integration-validation',
        'version': 2,
        'parserCommit': COMMIT,
        'parserTree': upstream['tree'],
        'measuredQudsCommit': published['measuredLocalCommit'],
        'publishedQudsSourceCommit': published['publishedCommit'],
        'measuredAndPublishedQudsTree': published['tree'],
        'publishedParent': published['parent'],
        'upstreamEntries': upstream['upstreamFileCount'],
        'unpatchedExactFiles': upstream['exactFileCount'],
        'allUpstreamModesVerified': True,
        'workspacePubspecSha256': upstream['workspacePubspecSha256'],
        'checks': summaries,
        'pythonTests': python_tests,
        'parserAnalyzer': diagnostics,
        'engineAnalyzer': 'No issues found; --fatal-infos enabled',
        'existingEngineSkip': {
            'path': 'test/wave4_platform_test.dart',
            'name': 'multi-face PDF embeds distinct font resources',
            'reason': 'Latin face already covers Arabic; cannot force F3',
        },
        'commands': commands,
        'artifactArchive': manifest['archive'],
        'artifactArchiveSha256': manifest['sha256'],
        'artifactMembers': len(artifacts),
        'artifactMembersVerified': True,
        'gateChanges': 'None: full test inventories, default VM/kernel and timeouts, unchanged skip logic, no filters or retries.',
    }
    write_json(OUTPUT / 'validation.json', summary)
    (OUTPUT / 'README.md').write_text(f'''# Quds integration of parser d14f03f

This receipt binds the complete workspace validation to canonical parser
`{COMMIT}` and tree `{upstream['tree']}`. All
{upstream['exactFileCount']} unpatched files match upstream byte for byte;
all {upstream['upstreamFileCount']} entry modes match. The sole content adaptation
is the existing workspace pubspec (workspace resolution, lints 6 and xml 7),
whose SHA256 remains `{upstream['workspacePubspecSha256']}`.

The measured clean Quds commit was `{published['measuredLocalCommit']}`.
The GitHub source checkpoint `{published['publishedCommit']}` has exactly
the same tree `{published['tree']}` and preserves current-main parent
`{published['parent']}`. The later receipt commit adds only evidence.

## Complete workspace checks

| Gate | Result |
| --- | --- |
| Parser Dart tests | 810 passed, zero failures or skips; all 66 suite files in 9 batches |
| Engine Dart tests | 1,627 passed, zero failures; all 123 suite files in 16 batches |
| Existing engine runtime skip | One: the selected Latin font already covers Arabic, so the multi-face font test cannot force a third font resource |
| Parser Python tests | 162 passed |
| Engine analyzer | Clean with `--fatal-infos` |
| Parser analyzer | Zero errors/warnings; 325 info diagnostics under the retained lints 6 / xml 7 workspace versions |
| Source stability | Exact before/after snapshots match for both complete test runs |

The portable parser's own dependency versions and SDK constraints are unchanged.
The parser analyzer's informational compatibility diagnostics are reported here;
no lint rules or CI gates were suppressed.

## Bounded test execution

The installed workspace resolves `test_core 0.6.18`, which retains compiled
suite kernels until a test process exits. Each batch therefore executes at most
eight sorted `*_test.dart` files with `dart test --concurrency=1 --reporter expanded`
and a JSON file reporter. VM/kernel compilation, timeouts, test selection inside
each suite and skip logic retain their defaults. All 123 engine paths and all
66 parser paths occur exactly once; the inventory includes each source SHA256.
There are no retries, name filters, omitted suites or fail-fast settings.

Every batch exited successfully and left no scratch files. Disk space was
checked at process boundaries; the reports retain those measurements, not an
unmeasured claim about the minimum space within each test process. The source
snapshots also bind the workspace dependency lock and package configuration.

`engine-report.json` and `parser-report.json` retain commands, environments,
counts and per-batch results. The corresponding inventories retain all suite
paths and hashes. `validation-artifacts.tar.xz` losslessly retains {len(artifacts)}
members: every expanded log, JSON event stream, batch record, before/after source
snapshot, the exact batch runners, analysis/Python logs and publication receipt.
Every decompressed member was checked against
`validation-artifacts.manifest.json`; archive SHA256 is `{manifest['sha256']}`.

## Fidelity scope

This is an integration receipt, not a claim that all Office fidelity gaps are
closed. The mirrored parser retains its current supported/remaining matrix and
the original native receipts, including genuine parser losses, DOC bridge losses
and renderer differences. No goldens, runtime behavior or existing test skip
conditions were changed for this validation.
''')
    print(json.dumps({key: summary[key] for key in ['parserCommit', 'publishedQudsSourceCommit', 'upstreamEntries', 'unpatchedExactFiles', 'artifactMembers', 'artifactArchiveSha256']}))


if __name__ == '__main__':
    main()
