#!/usr/bin/env python3
"""Run the entire Quds parser suite in deterministic, disk-bounded processes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/143959eed1a1/quds_office_suite')
ENGINE = ROOT / 'packages/legacy_doc_parser'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d')
DART = RUNTIME / 'flutter-3.47.8/bin/cache/dart-sdk/bin/dart'
SCRATCH = Path('/workspace/scratch/143959eed1a1/tmp')


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def snapshot():
    paths = set(git('ls-files', '--cached', '--others', '--exclude-standard', '-z').decode().split('\0'))
    paths.discard('')
    paths.update(['pubspec.lock', '.dart_tool/package_config.json'])
    files = {}
    for name in sorted(paths):
        path = ROOT / name
        if path.is_symlink():
            files[name] = {'symlink': os.readlink(path)}
        elif path.is_file():
            files[name] = {'sha256': sha256(path), 'size': path.stat().st_size}
        elif not path.exists():
            files[name] = {'missing': True}
        else:
            raise RuntimeError(f'Unexpected non-file source: {name}')
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'status': git('status', '--porcelain=v1', '-z').decode(),
        'files': files,
    }


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def event_summary(path):
    totals = {'passed': 0, 'failed': 0, 'skipped': 0, 'hidden': 0}
    completed = None
    seen = set()
    for line in path.read_text().splitlines():
        event = json.loads(line)
        if event.get('type') == 'done':
            completed = event.get('success')
        if event.get('type') != 'testDone':
            continue
        identity = event['testID']
        if identity in seen:
            raise RuntimeError(f'Duplicate testDone event: {identity}')
        seen.add(identity)
        if event.get('hidden', False):
            totals['hidden'] += 1
        elif event.get('skipped', False):
            totals['skipped'] += 1
        elif event.get('result') == 'success':
            totals['passed'] += 1
        else:
            totals['failed'] += 1
    return {'doneSuccess': completed, **totals}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('commit', help='Exact mirrored parser commit')
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--expected-suites', type=int, default=66)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{40}', args.commit):
        raise SystemExit('An exact 40-character parser commit is required.')
    if not 1 <= args.batch_size <= 8:
        raise SystemExit('Batch size must be between 1 and 8.')
    upstream = json.loads((ROOT / 'packages/legacy_doc_parser/UPSTREAM.json').read_text())
    if upstream['commit'] != args.commit:
        raise SystemExit(f'Parser pin mismatch: {upstream["commit"]}')
    test_files = sorted((ENGINE / 'test').rglob('*_test.dart'))
    if len(test_files) != args.expected_suites:
        raise SystemExit(f'Suite inventory changed: {len(test_files)} != {args.expected_suites}')
    if any(path.is_symlink() for path in test_files):
        raise SystemExit('Symlink suite requires explicit inventory review.')
    suite_inventory = [
        {'path': str(path.relative_to(ENGINE)), 'sha256': sha256(path)}
        for path in test_files
    ]
    paths = [entry['path'] for entry in suite_inventory]
    groups = [paths[index:index + args.batch_size] for index in range(0, len(paths), args.batch_size)]
    flattened = [path for group in groups for path in group]
    if flattened != paths or len(set(flattened)) != len(paths):
        raise SystemExit('Batch inventory is incomplete or duplicated.')
    package_config = json.loads((ROOT / '.dart_tool/package_config.json').read_text())
    test_core = next(package for package in package_config['packages'] if package['name'] == 'test_core')
    plan = {
        'parserCommit': args.commit,
        'suiteCount': len(paths),
        'batchSize': args.batch_size,
        'batchCount': len(groups),
        'runnerPackage': test_core,
        'suiteInventory': suite_inventory,
        'batches': groups,
        'baseCommand': [str(DART), 'test', '--concurrency=1', '--reporter', 'expanded'],
        'compiler': 'unchanged default VM/kernel',
        'timeoutsAndFilters': 'unchanged defaults; no filtering, retries, or fail-fast',
    }
    if args.plan_only:
        print(json.dumps(plan, indent=2))
        return

    before = snapshot()
    if before['status']:
        raise SystemExit('The complete parser gate requires a clean, committed source tree.')
    output = ROOT / 'build/parser-integration' / args.commit[:7] / 'parser-batches'
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / 'source-before.json', before)
    write_json(output / 'plan.json', plan)
    scratch_root = SCRATCH / f'quds-parser-{args.commit[:7]}'
    scratch_root.mkdir(parents=True, exist_ok=False)
    results = []
    executed = []
    start = time.monotonic()
    for index, group in enumerate(groups, 1):
        free_before = shutil.disk_usage(SCRATCH).free
        if free_before < 1024 ** 3:
            results.append({'batch': index, 'notStarted': 'Less than 1 GiB free', 'freeBytesBefore': free_before})
            break
        batch_scratch = scratch_root / f'{index:02d}'
        batch_scratch.mkdir()
        event_path = output / f'{index:02d}.events.jsonl'
        command = [*plan['baseCommand'], '--file-reporter', f'json:{event_path}', *group]
        environment = dict(os.environ, CI='true', TMPDIR=str(batch_scratch), PUB_CACHE=str(RUNTIME / 'pub-cache'))
        started = time.monotonic()
        with (output / f'{index:02d}.log').open('wb') as stream:
            result = subprocess.run(command, cwd=ENGINE, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=False)
        leftovers = {
            str(path.relative_to(batch_scratch)): path.stat().st_size
            for path in sorted(batch_scratch.rglob('*')) if path.is_file()
        }
        record = {
            'batch': index,
            'suites': group,
            'command': command,
            'directory': str(ENGINE.relative_to(ROOT)),
            'environment': {key: environment[key] for key in ['CI', 'TMPDIR', 'PUB_CACHE']},
            'exitCode': result.returncode,
            'durationSeconds': round(time.monotonic() - started, 3),
            'freeBytesBefore': free_before,
            'freeBytesAfter': shutil.disk_usage(SCRATCH).free,
            'remainingScratchFiles': leftovers,
            'eventsSha256': sha256(event_path) if event_path.exists() else None,
            'logSha256': sha256(output / f'{index:02d}.log'),
            'events': event_summary(event_path) if event_path.exists() else None,
        }
        results.append(record)
        executed.extend(group)
        write_json(output / f'{index:02d}.json', record)
        write_json(output / 'progress.json', results)
        print(json.dumps({key: record[key] for key in ['batch', 'exitCode', 'durationSeconds', 'freeBytesAfter', 'events']}), flush=True)
        # Retain any failed-cleanup files as evidence; only remove an empty directory.
        if not any(batch_scratch.iterdir()):
            batch_scratch.rmdir()
    after = snapshot()
    write_json(output / 'source-after.json', after)
    valid = (
        executed == paths
        and before == after
        and all(result.get('exitCode') == 0 and (result.get('events') or {}).get('doneSuccess') is True for result in results)
    )
    totals = {
        key: sum((result.get('events') or {}).get(key, 0) for result in results)
        for key in ['passed', 'failed', 'skipped', 'hidden']
    }
    report = {
        'parserCommit': args.commit,
        'qudsHead': before['head'],
        'success': valid,
        'sourceUnchanged': before == after,
        'allSuitesExactlyOnce': executed == paths,
        'suiteCount': len(paths),
        'executedSuiteCount': len(executed),
        'durationSeconds': round(time.monotonic() - start, 3),
        'testCounts': totals,
        'batches': results,
    }
    write_json(output / 'report.json', report)
    if not any(scratch_root.iterdir()):
        scratch_root.rmdir()
    print(json.dumps({key: report[key] for key in report if key != 'batches'}), flush=True)
    raise SystemExit(0 if valid else 1)


if __name__ == '__main__':
    main()
